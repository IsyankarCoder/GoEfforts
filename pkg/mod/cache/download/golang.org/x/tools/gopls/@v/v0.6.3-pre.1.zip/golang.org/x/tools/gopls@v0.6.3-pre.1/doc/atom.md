# Atom

Install the [`ide-gopls`] package.
You will also need to install the [`atom-ide-ui`] package.

[`ide-gopls`]: https://github.com/MordFustang21/ide-gopls
[`atom-ide-ui`]: https://github.com/facebookarchive/atom-ide-ui
